using System;
using Xamarin.Forms;

namespace DataTransfer6
{
    public partial class DataTransfer6InfoPage : ContentPage
    {
        public DataTransfer6InfoPage()
        {
            InitializeComponent();
        }
    }
}
