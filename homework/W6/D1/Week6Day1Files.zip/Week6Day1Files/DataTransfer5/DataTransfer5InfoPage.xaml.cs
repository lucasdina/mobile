using System;
using Xamarin.Forms;

namespace DataTransfer5
{
    public partial class DataTransfer5InfoPage : ContentPage
    {
        public DataTransfer5InfoPage()
        {
            InitializeComponent();
        }
    }
}
