using System;
using Xamarin.Forms;

namespace TextVariations
{
    public partial class TextVariationsPage : ContentPage
    {
        public TextVariationsPage()
        {
            InitializeComponent();
        }
    }
}
